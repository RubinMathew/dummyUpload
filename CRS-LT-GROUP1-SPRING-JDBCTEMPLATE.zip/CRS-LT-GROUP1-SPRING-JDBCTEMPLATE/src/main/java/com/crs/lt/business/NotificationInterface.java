package com.crs.lt.business;

public interface NotificationInterface {

	public boolean sendNotification();
}
