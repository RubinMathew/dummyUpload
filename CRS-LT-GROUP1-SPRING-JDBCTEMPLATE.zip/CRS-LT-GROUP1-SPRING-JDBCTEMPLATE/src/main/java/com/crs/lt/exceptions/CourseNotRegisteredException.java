package com.crs.lt.exceptions;

public class CourseNotRegisteredException extends Exception {

	public CourseNotRegisteredException(String string) {
		super(string);
	}

}
