package com.lt.crs.CRSLTSPRINGRESTJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrsLtSpringRestJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
