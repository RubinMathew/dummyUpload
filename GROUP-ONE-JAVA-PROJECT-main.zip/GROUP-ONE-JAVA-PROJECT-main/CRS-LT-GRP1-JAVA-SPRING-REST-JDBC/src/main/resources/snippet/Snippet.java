package snippet;

public class Snippet {
	 Failed to determine a suitable driver class
}

