package com.crs.lt.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrsLtGrp1JavaSpringRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
