package com.crs.lt.exceptions;

public class ProfessorNotFoundException extends Exception {

	private static final long serialVersionUID = 898632494119905276L;

	public ProfessorNotFoundException(String string) {
		// TODO Auto-generated constructor stub
super(string);
	}

}